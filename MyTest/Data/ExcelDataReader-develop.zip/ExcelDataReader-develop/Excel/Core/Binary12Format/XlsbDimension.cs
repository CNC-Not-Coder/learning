using System;
using System.Collections.Generic;
using System.Text;
using Excel.Core.OpenXmlFormat;

namespace Excel.Core.Binary12Format
{
	internal class XlsbDimension : XlsxDimension
	{
		public XlsbDimension():base(string.Empty) {}

	}
}
