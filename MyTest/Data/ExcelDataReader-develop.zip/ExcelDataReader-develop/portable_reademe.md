Notes:

Only BIFF8 is supported going forward. This is everything from and including Excel 97

Silverlight - 
Does not currently support Silverlight as there is no ZipArchive implementation on Silverlight

Also, ConcurrentDictionary is not available on Silverlight though that can be worked around

Windows Phone
As far as I can tell it should work with Windows Phone 8.1, but we need some one who has Windows 8 to build ExcelDataReader.WindowsPhone
