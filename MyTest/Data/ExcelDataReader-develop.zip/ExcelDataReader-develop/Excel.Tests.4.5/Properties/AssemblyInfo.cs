﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Excel.Tests")]
[assembly: AssemblyProduct("Excel.Tests")]

[assembly: ComVisible(false)]

[assembly: Guid("5649a0e5-7180-4363-a08f-08754fca3ca5")]

[assembly: AssemblyVersion("1.0.0.18")]
[assembly: AssemblyFileVersion("1.0.0.18")]
