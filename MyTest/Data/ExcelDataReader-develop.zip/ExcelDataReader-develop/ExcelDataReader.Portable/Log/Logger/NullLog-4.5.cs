﻿using System;

namespace ExcelDataReader.Portable.Log.Logger
{
	/// <summary>
	/// The default logger until one is set.
	/// </summary>
	public partial class NullLog : ILog, ILog<NullLog>
	{
		public void Debug(Func<string> message)
		{
		}

		public void Info(Func<string> message)
		{
		}

		public void Warn(Func<string> message)
		{
		}

		public void Error(Func<string> message)
		{
		}

		public void Fatal(Func<string> message)
		{
		}

	}
}
