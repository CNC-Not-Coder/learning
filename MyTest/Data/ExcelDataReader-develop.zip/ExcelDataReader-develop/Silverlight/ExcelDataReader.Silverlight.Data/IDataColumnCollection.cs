namespace ExcelDataReader.Silverlight.Data
{
	using System.Collections.Generic;

	public interface IDataColumnCollection : IList<IDataColumn>
	{
	}
}