namespace ExcelDataReader.Silverlight.Data
{
	using System.Collections.Generic;

	public interface IDataRowCollection : IList<IDataRow>
	{
	}
}