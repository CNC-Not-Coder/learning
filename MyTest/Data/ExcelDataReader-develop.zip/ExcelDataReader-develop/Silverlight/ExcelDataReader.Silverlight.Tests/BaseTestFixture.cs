namespace ExcelDataReader.Silverlight.Tests
{
	using NUnit.Framework;

	public class BaseTestFixture : AssertionHelper
	{
	}
}